package com.example.cmprojectandroid.Model

data class Favorite(
    val stop_id: String = "",
    val stop_name: String = ""
)