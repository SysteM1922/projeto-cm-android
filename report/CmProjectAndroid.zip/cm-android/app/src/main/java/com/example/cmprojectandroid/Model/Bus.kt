package com.example.cmprojectandroid.Model

data class Bus(
    val busId: String,
    val busName: String,
    val arrivalTime: String // You might want to use a DateTime type in a real app
)