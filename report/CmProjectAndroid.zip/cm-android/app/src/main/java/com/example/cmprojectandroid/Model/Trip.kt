package com.example.cmprojectandroid.Model

data class Trip (
    val trip_id: String = "",
    val trip_name: String = "",
    val timestamp: Long = 0,
)